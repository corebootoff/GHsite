from django.db import models

# Create your models here.

class Product(models.Model):
	name = models.CharField(verbose_name='Название', max_length=32)
	animal = models.CharField(verbose_name='Тип питомца', max_length=16)
	img = models.ImageField(null=True)
	info = models.TextField(null=True)
	weight = models.IntegerField(verbose_name='Вес')
	price = models.IntegerField(verbose_name='Цена')

	def __str__(self):
		return self.name