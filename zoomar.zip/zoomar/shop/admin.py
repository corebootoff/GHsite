from django.contrib import admin
from shop.models import Product

# Register your models here.

admin.site.register(Product)