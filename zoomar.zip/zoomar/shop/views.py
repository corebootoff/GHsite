from django.shortcuts import render

# Create your views here.

def mainpage(request):
	return render(request, 'shop/index.html')

def delivery(request):
	return render(request, 'shop/delivery.html')